import React from 'react';
import ReactDOM from 'react-dom';


//createPortal takes 2 args.
//One the ui to be rendered. Next where it has to be rendered

//On clicking on outside the modal box we should go back to root page.
//So we associate an event to our main div
//props.onDismiss has onDismiss={()=>history.push('/')}
//But this causes clicking anywhere inside the box also to go to root page
//Because other divs are child of main div
//Hence we need to stop propagating this event to child divs

const Modal= props =>{

	return ReactDOM.createPortal(
			<div 
			onClick={props.onDismiss}
			className="ui dimmer modals visible active">
				
				<div 
				onClick={(e)=>e.stopPropagation()}
				className="ui standard modal visible active">
					<div className="header">{props.title}</div>
					<div className="content">{props.content}</div>
					<div className="actions">{props.actions}</div>	
				</div>

			</div>,
			document.querySelector('#modal')
		);
};

export default Modal;