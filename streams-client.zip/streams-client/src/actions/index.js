import streams from '../apis/streams';
import {SIGN_IN,SIGN_OUT,CREATE_STREAM,FETCH_STREAMS,FETCH_STREAM ,DELETE_STREAM,EDIT_STREAM } from './types';
import history from '../history';

export const signIn=(userId)=>{
	return {
		type:SIGN_IN,
		payload:userId
	};
};

export const signOut=()=>{
	return {
		type:SIGN_OUT
	};
};

export const createStream = formValues=> async (dispatch,getState) =>{
	//We get userId from getState and append to state. Remember state will userId only we user is signedIn
	const {userId} = getState().auth;
	const response =await streams.post('/streams',{...formValues,userId});
	dispatch({type:CREATE_STREAM, payload:response.data});
	history.push('/');
	//To return to home page after we successful posting of stream
};

export const fetchStreams = () => async dispatch =>{
	const response =await streams.get('/streams');
	dispatch({type:FETCH_STREAMS, payload:response.data});
};

export const fetchStream = (id) => async dispatch =>{
	const response =await streams.get(`/streams/${id}`);
	dispatch({type:FETCH_STREAM, payload:response.data});
};

//It takes the id and updates the stream with updated formvalues in server 
//It is our job to find the existing stream with that id and update that state with new formvalues
// return{...state, [action.payload.id]:action.payload}
//So basically our state has {key:value} as {id:stream with that id}
//This above is the simplified syntax to search for matching ids and update our state!!


//Difference between put and patch
//put
//Replaces entire stream with formValues(remember formValues has only title and description here)
//stream(id,userId,oldtitle,olddescription) with stream(newtitle,newdescription) and id is automatically added. So stream(id,newtitle,newdescription)

//patch
//Replaces title and desc of stream with title and desc of formvalues
//stream(id,userId,oldtitle,olddescription) with stream(id,userId,newtitle,newdescription) 
export const editStream = (id,formValues) => async dispatch =>{
	const response =await streams.patch(`/streams/${id}`,formValues);
	dispatch({type:EDIT_STREAM, payload:response.data});
	history.push('/');
};

export const deleteStream = (id) => async dispatch =>{
	const response =await streams.delete(`/streams/${id}`);
	dispatch({type:DELETE_STREAM, payload:id});
	history.push('/');
};