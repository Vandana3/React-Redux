import {CREATE_STREAM,FETCH_STREAMS,FETCH_STREAM ,DELETE_STREAM,EDIT_STREAM } from '../actions/types';
import _ from 'lodash';
export default (state={},action)=>{
	switch(action.type){

		case FETCH_STREAM:
			return {...state,[action.payload.id]:action.payload};
		case CREATE_STREAM:
			return {...state,[action.payload.id]:action.payload};
		case EDIT_STREAM:
			return {...state,[action.payload.id]:action.payload};
		case DELETE_STREAM:
			return _.omit(state, action.payload);
			//Action.payload has only id.

		case FETCH_STREAMS:
			return {...state,..._.mapKeys(action.payload,'id')};
			//This above syntax is to convert
			//action.payload to the state we want
			// From [stream1(id1,title,desc),stream2(id2,title,desc),stream3(id3,title,desc)]
			//To {id1:stream1(id1,title,desc),
			//	  id2:stream2(id2,title,desc),
			//   id3:stream3(id3,title,desc)}		}
		default:
			return state;
	}
}