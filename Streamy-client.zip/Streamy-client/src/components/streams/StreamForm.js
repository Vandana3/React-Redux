import React from 'react';
import {Field,reduxForm} from 'redux-form';

class StreamForm extends React.Component{
	
	// renderInput(formProps){
		
	// 		<input onChange={formProps.input.onChange}
	// 				value={formProps.input.value}
	// 				/>
	// 		new Syntax below
	// 		return <input {...formProps.input}/>;
			
	// }

//After destructuring input from formProps
//The <Field> takes whatever prop we perovide such as label and send it to renderInput!!
		renderError({error,touched}){
			if(touched && error){
				return (
					<div className="ui error message">
					<div className="header">{error}</div>
					</div>
					);
			}
		}
//Made as arrow function to avoid problem of this
		renderInput=({input,label,meta})=>{
			//Make className as field error else just field(optional)
			const className=`field ${meta.error && meta.touched ? 'error': ''}`
			return (
				<div className={className}>
				<label>{label}</label>
				<input {...input} autoComplete="off"/>
				{this.renderError(meta)}
				</div>
				);		
	};
	//
//onSubmit prop is sent by streamCreate. Send formvalues via this onSubmit
//Those formValues are taken by streamCreate which is used to dispatch createStream action.
	onSubmit=(formValues)=>{
		this.props.onSubmit(formValues);
	};

//Form should have class as ui form error to show error messages

	render(){
		return(
			<form 
			onSubmit={this.props.handleSubmit(this.onSubmit)}
			className= "ui form error"> 
			<Field name="title" component={this.renderInput} label="Enter Title"/>
			<Field name="description" component={this.renderInput} label="Enter Description"/>
			<button className="ui button primary">Submit</button>
			</form>
			);
	}
}

const validate = (formValues)=>{
	const errors={};
	if(!formValues.title){
		errors.title="You must enter a title";
	}

	if(!formValues.description){
		errors.description="You must enter a description";
	}
	return errors;
}

// Very important.
// The error object returned will be sent to renderInput. 
// RenderInput recieves it as meta. meta.error gives the error message that we set.

//If only reduxForm is used!
export default reduxForm({
	form:'streamForm',
	validate
})(StreamForm);


// const formWrapped = reduxForm({
// 	form:'streamCreate',
// 	validate
// })(StreamCreate);

// export default connect(null,{createStream})(formWrapped);



