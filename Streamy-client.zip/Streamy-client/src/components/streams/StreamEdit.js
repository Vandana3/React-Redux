import React from 'react';
import _ from 'lodash';
import {connect} from 'react-redux';
import {fetchStream , editStream} from '../../actions';
import StreamForm from './StreamForm';

//ownProps are props passed down to component.
//ownProps.match.params.id has the id we pass in the url
//This id is passed (appended to url)when clicking on edit link in streamList page
// state.streams[ownProps.match.params.id]  gives us the stream with that id
//But Directly typing in id in url wont work . Redux state will be empty.
//Streams are loaded when we first render streamList
//But every component should work independant.
//Hence we need to load data here in this component too
//Thats why action fetchStream in componentDidMount
//initialvalues is a prop used to set initail values.
//this.props.streams's title and description will be initial values for title and description of form.
//FormValues has only title and description of stream here. Not entire stream.
//Because only those two fields should be sent to editStream action creator along with id!!


class StreamEdit extends React.Component{
	componentDidMount(){
		this.props.fetchStream(this.props.match.params.id);
	}

	onSubmit=(formValues)=>{
		this.props.editStream(this.props.match.params.id, formValues);
	}
	render(){
		if(!this.props.stream){
			return <div>Loading...</div>;
		}

		return(
		<div>
			<h3> Edit a stream </h3>
			<StreamForm 
			initialValues={_.pick(this.props.stream, 'title' , 'description')}
			onSubmit={this.onSubmit}/>
		</div>
		);
	}

}


const mapStateToProps=(state,ownProps)=>{
	return { stream: state.streams[ownProps.match.params.id] };
}
export default connect(mapStateToProps,{fetchStream , editStream})(StreamEdit);